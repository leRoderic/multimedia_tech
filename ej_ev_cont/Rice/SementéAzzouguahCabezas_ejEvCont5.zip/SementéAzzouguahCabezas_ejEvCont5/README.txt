======= README FIRST =======
- Se requiere de Jupyter Notebook (cualquier versión con Python 3.X
- Abrir el fichero ".YPYNB" con Jupyter Notebook.
- Clicar en las celdas con código y luego Shift+Enter para ejecutar.
- Algunas celdas requieren de código de las anteriores. Se deberán ejecutar.
- Las respuestas a las preguntas están en el notebook también, en formato Markdown.